﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace MarcKelleherLab4
{
    public partial class lab4Form : Form
    {
        public lab4Form()
        {
            InitializeComponent();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void statesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void inputBoxButton_Click(object sender, EventArgs e)
        {
            //Input box to find out information about visiting states and provide message to response.
            string inputYesOrNo = null;
            inputYesOrNo = Interaction.InputBox
                ("Do you plan to go to any of these states?" + Environment.NewLine + "Answer Yes or No"
                , "Your input needed");
            //Inputs string and converts to upper case.
            string yesOrNoResult = inputYesOrNo.ToUpper();
            if (yesOrNoResult == "YES")
            {
                //New MessageBox.
                MessageBox.Show("Maybe I'll see you there!", "That's Great", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            else if (yesOrNoResult == "NO")
            {
                //New MessageBox.
                MessageBox.Show("I probably won't see you there", "Too Bad", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            else
            {
                //New MessageBox.
                MessageBox.Show("Please Respond Yes or No", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the Exit menu item is selected. 
            exitButton.PerformClick();
        }

        private void utilitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void stateOregonButton_CheckedChanged(object sender, EventArgs e)
        {
            //The action that will take place if the Oregon radio button is selected. 
            if (stateOregonButton.Checked)
            {
                //Displays state image and information.
                generalFormToolTip.SetToolTip(statePictureBox, "Scenic Mount Hood");
                statePictureBox.Visible = true;
                statePictureBox.Image = Image.FromFile("Oregon.bmp");
                stateInfoGroupBox.Visible = true;
                stateInfoGroupBox.BackColor = Color.Green;
                stateOfLabel.Text = "STATE OF OREGON";
                stateOfLabel.ForeColor = Color.Yellow;
                populationInfoLabel.Text = "State of Oregon has a population \n of about 2 million people";
                climateInfoLabel.Text = "State of Oregon has a mild climate";
                nicknameInfoLabel.Text = "Beaver State";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //This code will not allow to be removed to run the program for some reason.
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exits the program.
            this.Close();
        }

        private void stateWashingtonButton_CheckedChanged(object sender, EventArgs e)
        {
            //The action that will take place if the Washington radio button is selected. 
            if (stateWashingtonButton.Checked)
            {
                //Displays state image and information.
                generalFormToolTip.SetToolTip(statePictureBox, "Scenic fountain with mountain in background");
                statePictureBox.Visible = true;
                statePictureBox.Image = Image.FromFile("washington.bmp");
                stateInfoGroupBox.Visible = true;
                stateInfoGroupBox.BackColor = Color.Blue;
                stateOfLabel.Text = "STATE OF WASHINGTON";
                stateOfLabel.ForeColor = Color.Yellow;
                populationInfoLabel.Text = "State of Washington has a \n population of about 2 million people";
                climateInfoLabel.Text = "State of Washington has a medium mild climate";
                nicknameInfoLabel.Text = "Salmon State";
            }
        }

        private void stateCaliforniaButton_CheckedChanged(object sender, EventArgs e)
        {
            //The action that will take place if the Washington radio button is selected. 
            if (stateCaliforniaButton.Checked)
            {
                //Displays state image and information.
                generalFormToolTip.SetToolTip(statePictureBox, "Scenic lighthouse overlooking the ocean");
                statePictureBox.Visible = true;
                statePictureBox.Image = Image.FromFile("california.bmp");
                stateInfoGroupBox.Visible = true;
                stateInfoGroupBox.BackColor = Color.Orange;
                stateOfLabel.Text = "STATE OF CALIFORNIA";
                stateOfLabel.ForeColor = Color.Yellow;
                populationInfoLabel.Text = "State of California has a \n population of about 34 million people";
                climateInfoLabel.Text = "State of California has a medium mild climate";
                nicknameInfoLabel.Text = "Golden State";
            }
        }

        private void oregonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the Oregon menu item is selected. 
            stateOregonButton.PerformClick();
        }

        private void clearAllButton_Click(object sender, EventArgs e)
        {
            //Clears all text boxes and hides all items normally not visible.
            statePictureBox.Visible = false;
            stateInfoGroupBox.Visible = false;
            stateOregonButton.Checked = false;
            stateWashingtonButton.Checked = false;
            stateCaliforniaButton.Checked = false;
            phoneCheckBox.Checked = false;
            phoneMaskedTextBox.Text = "";
            screenColorCheckBox.Checked = false;
            colorChangeGroupBox.Visible = false;
            phoneMaskedTextBox.Visible = false;
            this.BackColor = SystemColors.Control;
        }

        private void screenColorCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            //Changes the background color of the screen.
            if (screenColorCheckBox.Checked)
            {
                //Displays color options.
                colorChangeGroupBox.Visible = true;
            }
            else
            {
                //Hides color options.
                colorChangeGroupBox.Visible = false;
            }
        }

        private void phoneCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (phoneCheckBox.Checked)
            {
                //Displays phone number entry.
                phoneMaskedTextBox.Visible = true;
            }
            else
            {
                //Hides phone number entry.
                phoneMaskedTextBox.Visible = false;
            }
        }

        private void backgroundColorButton_Click(object sender, EventArgs e)
        {
            //Changes screen color based on input.
            switch (screenColorTextBox.Text.ToUpper())
            {
                case "GREEN":
                    this.BackColor = Color.Green;
                    break;
                case "BLUE":
                    this.BackColor = Color.Blue;
                    break;
                case "RED":
                    this.BackColor = Color.Red;
                    break;
                case "RESET":
                    this.BackColor = SystemColors.Control;
                    break;
                default:
                    MessageBox.Show("Enter one of the color choices");
                    break;

            }
        }

        private void washingtonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the Washington menu item is selected. 
            stateWashingtonButton.PerformClick();
        }

        private void californiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the California menu item is selected. 
            stateCaliforniaButton.PerformClick();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the Clear menu item is selected. 
            clearAllButton.PerformClick();
        }

        private void inputBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //The action that will take place if the Input Box menu item is selected. 
            inputBoxButton.PerformClick();
        }

        private void populationInfoLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
