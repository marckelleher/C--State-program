﻿namespace MarcKelleherLab4
{
    partial class lab4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(lab4Form));
            this.statesGroupBox = new System.Windows.Forms.GroupBox();
            this.stateCaliforniaButton = new System.Windows.Forms.RadioButton();
            this.stateWashingtonButton = new System.Windows.Forms.RadioButton();
            this.stateOregonButton = new System.Windows.Forms.RadioButton();
            this.optionsGroupBox = new System.Windows.Forms.GroupBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearAllButton = new System.Windows.Forms.Button();
            this.inputBoxButton = new System.Windows.Forms.Button();
            this.phoneCheckBox = new System.Windows.Forms.CheckBox();
            this.screenColorCheckBox = new System.Windows.Forms.CheckBox();
            this.stateMainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oregonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.washingtonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.californiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.utilitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stateLabel = new System.Windows.Forms.Label();
            this.statePictureBox = new System.Windows.Forms.PictureBox();
            this.stateInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.nicknameInfoLabel = new System.Windows.Forms.Label();
            this.nicknameLabel = new System.Windows.Forms.Label();
            this.climateInfoLabel = new System.Windows.Forms.Label();
            this.climateLabel = new System.Windows.Forms.Label();
            this.populationInfoLabel = new System.Windows.Forms.Label();
            this.populationFactsLabel = new System.Windows.Forms.Label();
            this.populationLabel = new System.Windows.Forms.Label();
            this.stateOfLabel = new System.Windows.Forms.Label();
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.colorChangeGroupBox = new System.Windows.Forms.GroupBox();
            this.backgroundColorButton = new System.Windows.Forms.Button();
            this.screenColorTextBox = new System.Windows.Forms.TextBox();
            this.colorOptionLabel = new System.Windows.Forms.Label();
            this.generalFormToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.statesGroupBox.SuspendLayout();
            this.optionsGroupBox.SuspendLayout();
            this.stateMainMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statePictureBox)).BeginInit();
            this.stateInfoGroupBox.SuspendLayout();
            this.colorChangeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // statesGroupBox
            // 
            this.statesGroupBox.Controls.Add(this.stateCaliforniaButton);
            this.statesGroupBox.Controls.Add(this.stateWashingtonButton);
            this.statesGroupBox.Controls.Add(this.stateOregonButton);
            this.statesGroupBox.Location = new System.Drawing.Point(92, 48);
            this.statesGroupBox.Name = "statesGroupBox";
            this.statesGroupBox.Size = new System.Drawing.Size(200, 100);
            this.statesGroupBox.TabIndex = 0;
            this.statesGroupBox.TabStop = false;
            this.statesGroupBox.Text = "States";
            // 
            // stateCaliforniaButton
            // 
            this.stateCaliforniaButton.AutoSize = true;
            this.stateCaliforniaButton.Location = new System.Drawing.Point(10, 75);
            this.stateCaliforniaButton.Name = "stateCaliforniaButton";
            this.stateCaliforniaButton.Size = new System.Drawing.Size(68, 17);
            this.stateCaliforniaButton.TabIndex = 2;
            this.stateCaliforniaButton.Text = "California";
            this.generalFormToolTip.SetToolTip(this.stateCaliforniaButton, "State of California");
            this.stateCaliforniaButton.UseVisualStyleBackColor = true;
            this.stateCaliforniaButton.CheckedChanged += new System.EventHandler(this.stateCaliforniaButton_CheckedChanged);
            // 
            // stateWashingtonButton
            // 
            this.stateWashingtonButton.AutoSize = true;
            this.stateWashingtonButton.Location = new System.Drawing.Point(10, 47);
            this.stateWashingtonButton.Name = "stateWashingtonButton";
            this.stateWashingtonButton.Size = new System.Drawing.Size(82, 17);
            this.stateWashingtonButton.TabIndex = 1;
            this.stateWashingtonButton.Text = "Washington";
            this.generalFormToolTip.SetToolTip(this.stateWashingtonButton, "State of Washington");
            this.stateWashingtonButton.UseVisualStyleBackColor = true;
            this.stateWashingtonButton.CheckedChanged += new System.EventHandler(this.stateWashingtonButton_CheckedChanged);
            // 
            // stateOregonButton
            // 
            this.stateOregonButton.AutoSize = true;
            this.stateOregonButton.Location = new System.Drawing.Point(10, 22);
            this.stateOregonButton.Name = "stateOregonButton";
            this.stateOregonButton.Size = new System.Drawing.Size(60, 17);
            this.stateOregonButton.TabIndex = 0;
            this.stateOregonButton.Text = "Oregon";
            this.generalFormToolTip.SetToolTip(this.stateOregonButton, "State of Oregon");
            this.stateOregonButton.UseVisualStyleBackColor = true;
            this.stateOregonButton.CheckedChanged += new System.EventHandler(this.stateOregonButton_CheckedChanged);
            // 
            // optionsGroupBox
            // 
            this.optionsGroupBox.Controls.Add(this.exitButton);
            this.optionsGroupBox.Controls.Add(this.clearAllButton);
            this.optionsGroupBox.Controls.Add(this.inputBoxButton);
            this.optionsGroupBox.Location = new System.Drawing.Point(92, 215);
            this.optionsGroupBox.Name = "optionsGroupBox";
            this.optionsGroupBox.Size = new System.Drawing.Size(175, 149);
            this.optionsGroupBox.TabIndex = 1;
            this.optionsGroupBox.TabStop = false;
            this.optionsGroupBox.Text = "Your Options";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(40, 111);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 29);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.generalFormToolTip.SetToolTip(this.exitButton, "Exit the program");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearAllButton
            // 
            this.clearAllButton.Location = new System.Drawing.Point(40, 71);
            this.clearAllButton.Name = "clearAllButton";
            this.clearAllButton.Size = new System.Drawing.Size(95, 29);
            this.clearAllButton.TabIndex = 1;
            this.clearAllButton.Text = "Clear All";
            this.generalFormToolTip.SetToolTip(this.clearAllButton, "Clear all fields");
            this.clearAllButton.UseVisualStyleBackColor = true;
            this.clearAllButton.Click += new System.EventHandler(this.clearAllButton_Click);
            // 
            // inputBoxButton
            // 
            this.inputBoxButton.Location = new System.Drawing.Point(40, 32);
            this.inputBoxButton.Name = "inputBoxButton";
            this.inputBoxButton.Size = new System.Drawing.Size(95, 29);
            this.inputBoxButton.TabIndex = 0;
            this.inputBoxButton.Text = "Input Box";
            this.generalFormToolTip.SetToolTip(this.inputBoxButton, "Click to see a message box");
            this.inputBoxButton.UseVisualStyleBackColor = true;
            this.inputBoxButton.Click += new System.EventHandler(this.inputBoxButton_Click);
            // 
            // phoneCheckBox
            // 
            this.phoneCheckBox.AutoSize = true;
            this.phoneCheckBox.Location = new System.Drawing.Point(46, 414);
            this.phoneCheckBox.Name = "phoneCheckBox";
            this.phoneCheckBox.Size = new System.Drawing.Size(63, 17);
            this.phoneCheckBox.TabIndex = 2;
            this.phoneCheckBox.Text = "Phone?";
            this.generalFormToolTip.SetToolTip(this.phoneCheckBox, "Click to enter the phone number");
            this.phoneCheckBox.UseVisualStyleBackColor = true;
            this.phoneCheckBox.CheckedChanged += new System.EventHandler(this.phoneCheckBox_CheckedChanged);
            // 
            // screenColorCheckBox
            // 
            this.screenColorCheckBox.AutoSize = true;
            this.screenColorCheckBox.Location = new System.Drawing.Point(46, 482);
            this.screenColorCheckBox.Name = "screenColorCheckBox";
            this.screenColorCheckBox.Size = new System.Drawing.Size(209, 17);
            this.screenColorCheckBox.TabIndex = 3;
            this.screenColorCheckBox.Text = "Click to change the color of the screen";
            this.screenColorCheckBox.UseVisualStyleBackColor = true;
            this.screenColorCheckBox.CheckedChanged += new System.EventHandler(this.screenColorCheckBox_CheckedChanged);
            // 
            // stateMainMenuStrip
            // 
            this.stateMainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.statesToolStripMenuItem,
            this.utilitiesToolStripMenuItem});
            this.stateMainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.stateMainMenuStrip.Name = "stateMainMenuStrip";
            this.stateMainMenuStrip.Size = new System.Drawing.Size(982, 24);
            this.stateMainMenuStrip.TabIndex = 4;
            this.stateMainMenuStrip.Text = "Menu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // statesToolStripMenuItem
            // 
            this.statesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oregonToolStripMenuItem,
            this.washingtonToolStripMenuItem,
            this.californiaToolStripMenuItem});
            this.statesToolStripMenuItem.Name = "statesToolStripMenuItem";
            this.statesToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.statesToolStripMenuItem.Text = "&States";
            this.statesToolStripMenuItem.Click += new System.EventHandler(this.statesToolStripMenuItem_Click);
            // 
            // oregonToolStripMenuItem
            // 
            this.oregonToolStripMenuItem.Name = "oregonToolStripMenuItem";
            this.oregonToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.oregonToolStripMenuItem.Text = "&Oregon";
            this.oregonToolStripMenuItem.Click += new System.EventHandler(this.oregonToolStripMenuItem_Click);
            // 
            // washingtonToolStripMenuItem
            // 
            this.washingtonToolStripMenuItem.Name = "washingtonToolStripMenuItem";
            this.washingtonToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.washingtonToolStripMenuItem.Text = "&Washington";
            this.washingtonToolStripMenuItem.Click += new System.EventHandler(this.washingtonToolStripMenuItem_Click);
            // 
            // californiaToolStripMenuItem
            // 
            this.californiaToolStripMenuItem.Name = "californiaToolStripMenuItem";
            this.californiaToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.californiaToolStripMenuItem.Text = "&California";
            this.californiaToolStripMenuItem.Click += new System.EventHandler(this.californiaToolStripMenuItem_Click);
            // 
            // utilitiesToolStripMenuItem
            // 
            this.utilitiesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputBoxToolStripMenuItem,
            this.clearToolStripMenuItem});
            this.utilitiesToolStripMenuItem.Name = "utilitiesToolStripMenuItem";
            this.utilitiesToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.utilitiesToolStripMenuItem.Text = "&Utilities";
            this.utilitiesToolStripMenuItem.Click += new System.EventHandler(this.utilitiesToolStripMenuItem_Click);
            // 
            // inputBoxToolStripMenuItem
            // 
            this.inputBoxToolStripMenuItem.Name = "inputBoxToolStripMenuItem";
            this.inputBoxToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.inputBoxToolStripMenuItem.Text = "Input Box";
            this.inputBoxToolStripMenuItem.Click += new System.EventHandler(this.inputBoxToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // stateLabel
            // 
            this.stateLabel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.stateLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.stateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.stateLabel.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.stateLabel.Location = new System.Drawing.Point(373, 51);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(219, 41);
            this.stateLabel.TabIndex = 5;
            this.stateLabel.Text = "State";
            this.stateLabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.generalFormToolTip.SetToolTip(this.stateLabel, "State Information");
            // 
            // statePictureBox
            // 
            this.statePictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.statePictureBox.Location = new System.Drawing.Point(492, 123);
            this.statePictureBox.Name = "statePictureBox";
            this.statePictureBox.Size = new System.Drawing.Size(171, 90);
            this.statePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.statePictureBox.TabIndex = 6;
            this.statePictureBox.TabStop = false;
            this.statePictureBox.Visible = false;
            // 
            // stateInfoGroupBox
            // 
            this.stateInfoGroupBox.BackColor = System.Drawing.SystemColors.Control;
            this.stateInfoGroupBox.Controls.Add(this.nicknameInfoLabel);
            this.stateInfoGroupBox.Controls.Add(this.nicknameLabel);
            this.stateInfoGroupBox.Controls.Add(this.climateInfoLabel);
            this.stateInfoGroupBox.Controls.Add(this.climateLabel);
            this.stateInfoGroupBox.Controls.Add(this.populationInfoLabel);
            this.stateInfoGroupBox.Controls.Add(this.populationFactsLabel);
            this.stateInfoGroupBox.Controls.Add(this.populationLabel);
            this.stateInfoGroupBox.Controls.Add(this.stateOfLabel);
            this.stateInfoGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateInfoGroupBox.ForeColor = System.Drawing.SystemColors.Control;
            this.stateInfoGroupBox.Location = new System.Drawing.Point(424, 231);
            this.stateInfoGroupBox.Name = "stateInfoGroupBox";
            this.stateInfoGroupBox.Size = new System.Drawing.Size(507, 376);
            this.stateInfoGroupBox.TabIndex = 7;
            this.stateInfoGroupBox.TabStop = false;
            this.stateInfoGroupBox.Text = "State Information";
            this.stateInfoGroupBox.Visible = false;
            // 
            // nicknameInfoLabel
            // 
            this.nicknameInfoLabel.AutoSize = true;
            this.nicknameInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicknameInfoLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.nicknameInfoLabel.Location = new System.Drawing.Point(65, 310);
            this.nicknameInfoLabel.Name = "nicknameInfoLabel";
            this.nicknameInfoLabel.Size = new System.Drawing.Size(179, 24);
            this.nicknameInfoLabel.TabIndex = 17;
            this.nicknameInfoLabel.Text = "Nickname data here";
            // 
            // nicknameLabel
            // 
            this.nicknameLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nicknameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicknameLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.nicknameLabel.Location = new System.Drawing.Point(6, 269);
            this.nicknameLabel.Name = "nicknameLabel";
            this.nicknameLabel.Size = new System.Drawing.Size(140, 39);
            this.nicknameLabel.TabIndex = 16;
            this.nicknameLabel.Text = "Nickname";
            this.nicknameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // climateInfoLabel
            // 
            this.climateInfoLabel.AutoSize = true;
            this.climateInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.climateInfoLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.climateInfoLabel.Location = new System.Drawing.Point(63, 221);
            this.climateInfoLabel.Name = "climateInfoLabel";
            this.climateInfoLabel.Size = new System.Drawing.Size(156, 24);
            this.climateInfoLabel.TabIndex = 15;
            this.climateInfoLabel.Text = "Climate data here";
            // 
            // climateLabel
            // 
            this.climateLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.climateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.climateLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.climateLabel.Location = new System.Drawing.Point(6, 178);
            this.climateLabel.Name = "climateLabel";
            this.climateLabel.Size = new System.Drawing.Size(140, 39);
            this.climateLabel.TabIndex = 14;
            this.climateLabel.Text = "Climate";
            this.climateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // populationInfoLabel
            // 
            this.populationInfoLabel.AutoSize = true;
            this.populationInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.populationInfoLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.populationInfoLabel.Location = new System.Drawing.Point(65, 124);
            this.populationInfoLabel.Name = "populationInfoLabel";
            this.populationInfoLabel.Size = new System.Drawing.Size(183, 24);
            this.populationInfoLabel.TabIndex = 13;
            this.populationInfoLabel.Text = "Population data here";
            this.populationInfoLabel.Click += new System.EventHandler(this.populationInfoLabel_Click);
            // 
            // populationFactsLabel
            // 
            this.populationFactsLabel.AutoSize = true;
            this.populationFactsLabel.Location = new System.Drawing.Point(65, 143);
            this.populationFactsLabel.Name = "populationFactsLabel";
            this.populationFactsLabel.Size = new System.Drawing.Size(0, 20);
            this.populationFactsLabel.TabIndex = 12;
            this.populationFactsLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // populationLabel
            // 
            this.populationLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.populationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.populationLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.populationLabel.Location = new System.Drawing.Point(6, 86);
            this.populationLabel.Name = "populationLabel";
            this.populationLabel.Size = new System.Drawing.Size(140, 39);
            this.populationLabel.TabIndex = 11;
            this.populationLabel.Text = "Population";
            this.populationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // stateOfLabel
            // 
            this.stateOfLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateOfLabel.Location = new System.Drawing.Point(17, 35);
            this.stateOfLabel.Name = "stateOfLabel";
            this.stateOfLabel.Size = new System.Drawing.Size(331, 37);
            this.stateOfLabel.TabIndex = 10;
            this.stateOfLabel.Text = "STATE OF CALIFORNIA";
            this.stateOfLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(46, 437);
            this.phoneMaskedTextBox.Mask = "(999) 000-0000";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneMaskedTextBox.TabIndex = 8;
            this.phoneMaskedTextBox.Visible = false;
            // 
            // colorChangeGroupBox
            // 
            this.colorChangeGroupBox.Controls.Add(this.backgroundColorButton);
            this.colorChangeGroupBox.Controls.Add(this.screenColorTextBox);
            this.colorChangeGroupBox.Controls.Add(this.colorOptionLabel);
            this.colorChangeGroupBox.Location = new System.Drawing.Point(46, 513);
            this.colorChangeGroupBox.Name = "colorChangeGroupBox";
            this.colorChangeGroupBox.Size = new System.Drawing.Size(361, 100);
            this.colorChangeGroupBox.TabIndex = 9;
            this.colorChangeGroupBox.TabStop = false;
            this.colorChangeGroupBox.Text = "Choose Color";
            this.colorChangeGroupBox.Visible = false;
            // 
            // backgroundColorButton
            // 
            this.backgroundColorButton.Location = new System.Drawing.Point(16, 48);
            this.backgroundColorButton.Name = "backgroundColorButton";
            this.backgroundColorButton.Size = new System.Drawing.Size(108, 23);
            this.backgroundColorButton.TabIndex = 2;
            this.backgroundColorButton.Text = "&Background Color";
            this.backgroundColorButton.UseVisualStyleBackColor = true;
            this.backgroundColorButton.Click += new System.EventHandler(this.backgroundColorButton_Click);
            // 
            // screenColorTextBox
            // 
            this.screenColorTextBox.Location = new System.Drawing.Point(201, 9);
            this.screenColorTextBox.Name = "screenColorTextBox";
            this.screenColorTextBox.Size = new System.Drawing.Size(135, 20);
            this.screenColorTextBox.TabIndex = 1;
            // 
            // colorOptionLabel
            // 
            this.colorOptionLabel.AutoSize = true;
            this.colorOptionLabel.Location = new System.Drawing.Point(3, 16);
            this.colorOptionLabel.Name = "colorOptionLabel";
            this.colorOptionLabel.Size = new System.Drawing.Size(135, 13);
            this.colorOptionLabel.TabIndex = 0;
            this.colorOptionLabel.Text = "Green, Blue, Red, or Reset";
            // 
            // lab4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 641);
            this.Controls.Add(this.colorChangeGroupBox);
            this.Controls.Add(this.phoneMaskedTextBox);
            this.Controls.Add(this.stateInfoGroupBox);
            this.Controls.Add(this.statePictureBox);
            this.Controls.Add(this.stateLabel);
            this.Controls.Add(this.screenColorCheckBox);
            this.Controls.Add(this.phoneCheckBox);
            this.Controls.Add(this.optionsGroupBox);
            this.Controls.Add(this.statesGroupBox);
            this.Controls.Add(this.stateMainMenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.stateMainMenuStrip;
            this.Name = "lab4Form";
            this.Text = "Favorite States";
            this.statesGroupBox.ResumeLayout(false);
            this.statesGroupBox.PerformLayout();
            this.optionsGroupBox.ResumeLayout(false);
            this.stateMainMenuStrip.ResumeLayout(false);
            this.stateMainMenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statePictureBox)).EndInit();
            this.stateInfoGroupBox.ResumeLayout(false);
            this.stateInfoGroupBox.PerformLayout();
            this.colorChangeGroupBox.ResumeLayout(false);
            this.colorChangeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox statesGroupBox;
        private System.Windows.Forms.RadioButton stateCaliforniaButton;
        private System.Windows.Forms.RadioButton stateWashingtonButton;
        private System.Windows.Forms.RadioButton stateOregonButton;
        protected System.Windows.Forms.GroupBox optionsGroupBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearAllButton;
        private System.Windows.Forms.Button inputBoxButton;
        private System.Windows.Forms.CheckBox phoneCheckBox;
        private System.Windows.Forms.CheckBox screenColorCheckBox;
        private System.Windows.Forms.MenuStrip stateMainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oregonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem washingtonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem californiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem utilitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.PictureBox statePictureBox;
        private System.Windows.Forms.GroupBox stateInfoGroupBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.GroupBox colorChangeGroupBox;
        private System.Windows.Forms.Button backgroundColorButton;
        private System.Windows.Forms.TextBox screenColorTextBox;
        private System.Windows.Forms.Label colorOptionLabel;
        private System.Windows.Forms.Label populationFactsLabel;
        private System.Windows.Forms.Label populationLabel;
        private System.Windows.Forms.Label stateOfLabel;
        private System.Windows.Forms.Label populationInfoLabel;
        private System.Windows.Forms.Label climateLabel;
        private System.Windows.Forms.Label climateInfoLabel;
        private System.Windows.Forms.Label nicknameInfoLabel;
        private System.Windows.Forms.Label nicknameLabel;
        private System.Windows.Forms.ToolTip generalFormToolTip;
    }
}

